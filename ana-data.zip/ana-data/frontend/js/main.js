// ============================================
// ANA DATA - Main search logic
// ============================================

// ===== API Banner / Config =====
(function initApiBanner() {
  const banner = document.getElementById('apiBanner');
  const bannerText = document.getElementById('apiBannerText');
  const configBtn = document.getElementById('configApiBtn');
  const apiModal = document.getElementById('apiModal');
  const closeApi = document.getElementById('closeApi');
  const apiForm = document.getElementById('apiForm');
  const apiInput = document.getElementById('apiUrlInput');
  const apiMsg = document.getElementById('apiMsg');
  const useDemoBtn = document.getElementById('useDemoBtn');

  function showBanner(state, text) {
    if (!banner) return;
    banner.classList.toggle('connected', state === 'connected');
    bannerText.textContent = text;
  }

  async function checkBackend() {
    const base = API.BASE_URL;
    if (!base || base === '/api') {
      showBanner('demo', 'وضع العرض التجريبي — للبحث الحقيقي شغّل الباك إند من مجلد backend');
      return;
    }
    try {
      const res = await fetch(base + '/config', { method: 'GET' });
      if (res.ok) {
        showBanner('connected', 'متصل بقاعدة بيانات تليجرام الحقيقية ✓');
      } else {
        showBanner('demo', 'الباك إند مش متاح — وضع العرض التجريبي مفعّل');
      }
    } catch {
      showBanner('demo', 'وضع العرض التجريبي — للبحث الحقيقي شغّل الباك إند من مجلد backend');
    }
  }

  function openApiModal() {
    if (!apiModal) return;
    apiModal.style.display = 'grid';
    document.body.style.overflow = 'hidden';
    apiInput.value = API.BASE_URL === '/api' ? '' : API.BASE_URL;
  }
  function closeApiModal() {
    if (!apiModal) return;
    apiModal.style.display = 'none';
    document.body.style.overflow = '';
  }

  configBtn?.addEventListener('click', openApiModal);
  closeApi?.addEventListener('click', closeApiModal);
  apiModal?.querySelector('.modal-backdrop')?.addEventListener('click', closeApiModal);

  apiForm?.addEventListener('submit', (e) => {
    e.preventDefault();
    const url = apiInput.value.trim();
    if (!url) {
      apiMsg.className = 'form-msg error';
      apiMsg.textContent = 'اكتب الرابط الأول';
      return;
    }
    const clean = url.replace(/\/+$/, '');
    localStorage.setItem('api_base_url', clean);
    apiMsg.className = 'form-msg success';
    apiMsg.textContent = 'تم الحفظ، جاري إعادة التحميل...';
    setTimeout(() => location.reload(), 700);
  });

  useDemoBtn?.addEventListener('click', () => {
    localStorage.removeItem('api_base_url');
    apiMsg.className = 'form-msg success';
    apiMsg.textContent = 'تم التحويل لوضع العرض';
    setTimeout(() => location.reload(), 600);
  });

  checkBackend();
})();

(function () {
  const input = document.getElementById('usernameInput');
  const btn = document.getElementById('searchBtn');
  const onlyActive = document.getElementById('onlyActive');
  const resultArea = document.getElementById('resultArea');
  const resultLoader = document.getElementById('resultLoader');
  const resultCard = document.getElementById('resultCard');
  const resultError = document.getElementById('resultError');

  // Result fields
  const resultName = document.getElementById('resultName');
  const resultUsername = document.getElementById('resultUsername');
  const resultPhone = document.getElementById('resultPhone');
  const resultId = document.getElementById('resultId');
  const resultActive = document.getElementById('resultActive');
  const resultStatus = document.getElementById('resultStatus');
  const errorTitle = document.getElementById('errorTitle');
  const errorMsg = document.getElementById('errorMsg');

  function showLoader() {
    resultArea.style.display = 'block';
    resultLoader.style.display = 'flex';
    resultCard.style.display = 'none';
    resultError.style.display = 'none';
    resultArea.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }

  function showResult(d) {
    resultLoader.style.display = 'none';
    resultError.style.display = 'none';
    resultCard.style.display = 'block';
    resultName.textContent = d.name || '—';
    resultUsername.textContent = '@' + (d.username || '—');
    resultPhone.textContent = d.phone || '—';
    resultId.textContent = d.id || '—';
    resultActive.textContent = d.activeMonths
      ? `+${d.activeMonths} شهر`
      : '—';
    resultStatus.textContent = d.status || '—';
  }

  function showError(title, msg) {
    resultLoader.style.display = 'none';
    resultCard.style.display = 'none';
    resultError.style.display = 'block';
    errorTitle.textContent = title;
    errorMsg.textContent = msg;
  }

  async function doSearch() {
    const raw = (input.value || '').trim();
    if (!raw) {
      showError('اكتب يوزر الأول', 'من فضلك اكتب يوزر تليجرام في خانة البحث.');
      input.focus();
      return;
    }

    // Require login
    if (!API.getToken()) {
      showError('لازم تسجل دخول', 'سجّل دخولك مجاناً عشان تستخدم الأداة.');
      setTimeout(() => Auth.open('login'), 600);
      return;
    }

    showLoader();
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري البحث';

    try {
      let res;
      // If no backend configured, go straight to demo
      if (!API.BASE_URL) {
        await new Promise(r => setTimeout(r, 1100));
        const demoRes = demoSearch(raw);
        res = demoRes.ok ? { ok: true, data: demoRes.data, _demo: true } : demoRes;
      } else {
        // Try real API
        try {
          res = await API.search(raw);
        } catch (err) {
          if (err.message?.includes('Failed to fetch') || err.message?.includes('NetworkError') || err.status === 404) {
            await new Promise(r => setTimeout(r, 700));
            const demoRes = demoSearch(raw);
            res = demoRes.ok ? { ok: true, data: demoRes.data, _demo: true } : demoRes;
          } else {
            throw err;
          }
        }
      }

      if (!res.ok) {
        showError('لم يتم العثور على نتائج', res.error || 'تأكد من كتابة اليوزر بشكل صحيح.');
      } else {
        const d = res.data;
        // Filter active +6 months
        if (onlyActive.checked && d.activeMonths && d.activeMonths < 6) {
          showError('اليوزر ده جديد', 'هذا الحساب نشط منذ أقل من 6 أشهر، وبالتالي الرقم غير متاح في قاعدة البيانات.');
        } else {
          showResult(d);
          // Decrement points locally for feedback
          const u = API.getUser();
          if (u && typeof u.points === 'number') {
            u.points = Math.max(0, u.points - 1);
            API.setUser(u);
            if (window.Auth) Auth.updateUI();
          }
        }
      }
    } catch (err) {
      showError('حصل مشكلة', err.message || 'حاول مرة تانية بعد شوية.');
    } finally {
      btn.disabled = false;
      btn.innerHTML = '<i class="fas fa-search"></i><span>بحث</span>';
    }
  }

  btn?.addEventListener('click', doSearch);
  input?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') doSearch();
  });

  // Smooth scroll for nav links
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', (e) => {
      const id = a.getAttribute('href');
      if (id.length > 1) {
        const el = document.querySelector(id);
        if (el) {
          e.preventDefault();
          el.scrollIntoView({ behavior: 'smooth' });
        }
      }
    });
  });

  // Animated counter on stats
  const stats = document.querySelectorAll('.stat-num');
  const animate = (el, target) => {
    const num = parseInt(String(target).replace(/[^0-9]/g, '')) || 0;
    let cur = 0;
    const step = Math.max(1, Math.ceil(num / 40));
    const id = setInterval(() => {
      cur += step;
      if (cur >= num) { cur = num; clearInterval(id); }
      el.textContent = '+' + cur + (String(target).includes('K') ? 'K' : '');
    }, 30);
  };
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        animate(e.target, e.target.textContent);
        observer.unobserve(e.target);
      }
    });
  });
  stats.forEach(s => observer.observe(s));
})();
