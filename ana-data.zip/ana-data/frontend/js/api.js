// ============================================
// ANA DATA - API Client
// Handles all backend communication
// ============================================

const API = (() => {
  // في الإنتاج، حط رابط الباك إند بتاعك هنا
  // مثال: 'https://api.your-domain.com'
  const BASE_URL = (() => {
    const override = localStorage.getItem('api_base_url');
    if (override) return override;
    // If on the deployed site (miniMax space), default to no backend (empty)
    // so demo mode works by default. Users can configure via the UI.
    const isDeployed = window.location.hostname.endsWith('.space.minimax.io') ||
                       window.location.hostname.endsWith('.minimax.io');
    if (isDeployed) return '';   // empty -> demo mode in main.js
    return '/api';
  })();

  const TOKEN_KEY = 'ana_data_token';
  const USER_KEY = 'ana_data_user';

  function getToken() {
    return localStorage.getItem(TOKEN_KEY);
  }
  function setToken(t) {
    if (t) localStorage.setItem(TOKEN_KEY, t);
    else localStorage.removeItem(TOKEN_KEY);
  }
  function getUser() {
    try { return JSON.parse(localStorage.getItem(USER_KEY)); }
    catch { return null; }
  }
  function setUser(u) {
    if (u) localStorage.setItem(USER_KEY, JSON.stringify(u));
    else localStorage.removeItem(USER_KEY);
  }

  async function request(path, opts = {}) {
    const headers = Object.assign(
      { 'Content-Type': 'application/json' },
      opts.headers || {}
    );
    const token = getToken();
    if (token) headers['Authorization'] = `Bearer ${token}`;

    const res = await fetch(BASE_URL + path, {
      method: opts.method || 'GET',
      headers,
      body: opts.body ? JSON.stringify(opts.body) : undefined,
    });

    let data;
    try { data = await res.json(); }
    catch { data = { ok: false, error: 'استجابة غير صحيحة من السيرفر' }; }

    if (!res.ok) {
      const err = new Error(data.error || data.message || 'حدث خطأ');
      err.status = res.status;
      err.data = data;
      throw err;
    }
    return data;
  }

  return {
    BASE_URL,
    setBaseUrl: (url) => { localStorage.setItem('api_base_url', url); location.reload(); },
    getToken, setToken, getUser, setUser,

    // ===== Auth =====
    register: (name, email, password) =>
      request('/auth/register', { method: 'POST', body: { name, email, password } }),

    login: (email, password) =>
      request('/auth/login', { method: 'POST', body: { email, password } }),

    me: () => request('/auth/me'),

    // ===== Search =====
    search: (username) =>
      request('/search', { method: 'POST', body: { username } }),

    // ===== Admin =====
    adminStats: () => request('/admin/stats'),
    adminUsers: () => request('/admin/users'),
    adminSearches: (limit = 50) => request(`/admin/searches?limit=${limit}`),
    adminConfig: () => request('/admin/config'),
    adminUpdateUser: (id, data) =>
      request(`/admin/users/${id}`, { method: 'PATCH', body: data }),
    adminDeleteUser: (id) =>
      request(`/admin/users/${id}`, { method: 'DELETE' }),
  };
})();

// ============================================
// Demo fallback (works without backend)
// ============================================
const DEMO_MODE = API.BASE_URL === '/api' && !window.location.hostname.includes('localhost');
// If user is on file:// or no backend, we still provide a demo experience
// by returning simulated results from a small built-in dataset.
// This lets the UI work end-to-end during local preview.

const DEMO_DATA = [
  { username: 'ahmed', name: 'Ahmed Mohamed', phone: '+201012345678', id: 100200300, activeMonths: 14, status: 'مرئي' },
  { username: 'sara', name: 'Sara Ali', phone: '+201112345678', id: 100200301, activeMonths: 9, status: 'مرئي' },
  { username: 'mahmoud', name: 'Mahmoud Hassan', phone: '+201234567890', id: 100200302, activeMonths: 22, status: 'مرئي' },
  { username: 'telegram', name: 'Telegram', phone: '—', id: 100200303, activeMonths: 80, status: 'بدون رقم' },
  { username: 'durov', name: 'Pavel Durov', phone: '—', id: 100200304, activeMonths: 120, status: 'مخفي' },
];

function demoSearch(username) {
  const q = username.replace(/^@/, '').trim().toLowerCase();
  if (!q) return { ok: false, error: 'اكتب يوزر صحيح' };
  const hit = DEMO_DATA.find(d => d.username === q);
  if (hit) return { ok: true, data: hit };
  // Random simulated result
  if (q.length >= 4) {
    const randomPhone = '+2011' + Math.floor(10000000 + Math.random() * 89999999);
    return {
      ok: true,
      data: {
        username: q,
        name: q.charAt(0).toUpperCase() + q.slice(1),
        phone: randomPhone,
        id: Math.floor(100000000 + Math.random() * 900000000),
        activeMonths: 6 + Math.floor(Math.random() * 36),
        status: 'مرئي',
      }
    };
  }
  return { ok: false, error: 'لم يتم العثور على نتائج. تأكد من كتابة اليوزر بشكل صحيح.' };
}

window.API = API;
window.demoSearch = demoSearch;
