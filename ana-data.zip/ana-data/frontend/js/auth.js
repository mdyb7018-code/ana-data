// ============================================
// ANA DATA - Auth UI
// ============================================

const Auth = (() => {
  const modal = document.getElementById('authModal');
  const loginBtn = document.getElementById('loginBtn');
  const logoutBtn = document.getElementById('logoutBtn');
  const closeBtn = document.getElementById('closeAuth');
  const backdrop = modal?.querySelector('.modal-backdrop');
  const tabs = modal?.querySelectorAll('.tab');
  const forms = {
    login: document.getElementById('loginForm'),
    register: document.getElementById('registerForm'),
  };
  const msgs = {
    login: document.getElementById('loginMsg'),
    register: document.getElementById('registerMsg'),
  };

  const userInfo = document.getElementById('userInfo');
  const userName = document.getElementById('userName');
  const userPoints = document.getElementById('userPoints');

  function open(tab = 'login') {
    if (!modal) return;
    modal.style.display = 'grid';
    switchTab(tab);
    document.body.style.overflow = 'hidden';
  }
  function close() {
    if (!modal) return;
    modal.style.display = 'none';
    document.body.style.overflow = '';
  }
  function switchTab(tab) {
    tabs?.forEach(t => t.classList.toggle('active', t.dataset.tab === tab));
    Object.entries(forms).forEach(([k, f]) => {
      if (f) f.classList.toggle('active', k === tab);
    });
  }

  function showMsg(type, key, text) {
    if (!msgs[key]) return;
    msgs[key].className = 'form-msg ' + type;
    msgs[key].textContent = text;
  }

  function updateUI() {
    const user = API.getUser();
    if (user) {
      userInfo.style.display = 'flex';
      loginBtn.style.display = 'none';
      userName.textContent = user.name || user.email;
      userPoints.textContent = user.points ?? 0;
    } else {
      userInfo.style.display = 'none';
      loginBtn.style.display = 'inline-flex';
    }
  }

  // ===== Events =====
  loginBtn?.addEventListener('click', () => open('login'));
  closeBtn?.addEventListener('click', close);
  backdrop?.addEventListener('click', close);
  tabs?.forEach(t => t.addEventListener('click', () => switchTab(t.dataset.tab)));

  logoutBtn?.addEventListener('click', () => {
    API.setToken(null);
    API.setUser(null);
    updateUI();
    toast('تم تسجيل خروجك', 'success');
  });

  forms.login?.addEventListener('submit', async (e) => {
    e.preventDefault();
    showMsg('', 'login', 'جاري الدخول...');
    const fd = new FormData(e.target);
    const email = fd.get('email').trim().toLowerCase();
    const password = fd.get('password');

    // Special admin shortcut in demo mode
    const isAdminEmail = email === 'mdyb7018@gmail.com' && password === 'admin123456';

    if (!API.BASE_URL) {
      // Demo mode: local fake session
      await new Promise(r => setTimeout(r, 500));
      API.setToken('demo-' + btoa(email));
      API.setUser({
        id: isAdminEmail ? 1 : Date.now(),
        name: isAdminEmail ? 'Admin' : email.split('@')[0],
        email,
        points: 9999,
        role: isAdminEmail ? 'admin' : 'user',
      });
      updateUI();
      close();
      toast(isAdminEmail ? 'أهلاً يا أدمن 👑' : 'أهلاً بيك!', 'success');
      return;
    }

    try {
      const res = await API.login(email, password);
      API.setToken(res.token);
      API.setUser(res.user);
      updateUI();
      close();
      toast('أهلاً بيك!', 'success');
    } catch (err) {
      showMsg('error', 'login', err.message || 'بيانات الدخول غلط');
    }
  });

  forms.register?.addEventListener('submit', async (e) => {
    e.preventDefault();
    showMsg('', 'register', 'جاري إنشاء الحساب...');
    const fd = new FormData(e.target);
    const name = fd.get('name').trim();
    const email = fd.get('email').trim().toLowerCase();
    const password = fd.get('password');

    if (!API.BASE_URL) {
      // Demo mode: local fake session
      await new Promise(r => setTimeout(r, 500));
      API.setToken('demo-' + btoa(email));
      API.setUser({
        id: Date.now(),
        name,
        email,
        points: 100,
        role: 'user',
      });
      updateUI();
      close();
      toast('تم إنشاء حسابك بنجاح!', 'success');
      return;
    }

    try {
      const res = await API.register(name, email, password);
      API.setToken(res.token);
      API.setUser(res.user);
      updateUI();
      close();
      toast('تم إنشاء حسابك بنجاح!', 'success');
    } catch (err) {
      showMsg('error', 'register', err.message || 'حصل مشكلة في التسجيل');
    }
  });

  // Auto-refresh user on load
  async function refresh() {
    const token = API.getToken();
    if (!token) { updateUI(); return; }
    // No backend -> just refresh UI from stored data
    if (!API.BASE_URL) { updateUI(); return; }
    try {
      const res = await API.me();
      API.setUser(res.user);
      updateUI();
    } catch {
      const isDemo = window.location.protocol === 'file:' ||
                     (window.location.hostname === '' || window.location.hostname === 'localhost');
      if (!isDemo) {
        API.setToken(null);
        API.setUser(null);
      }
      updateUI();
    }
  }

  // Toast helper
  function toast(text, type = 'info') {
    const t = document.createElement('div');
    t.className = 'toast toast-' + type;
    t.textContent = text;
    Object.assign(t.style, {
      position: 'fixed',
      bottom: '24px',
      left: '50%',
      transform: 'translateX(-50%)',
      background: type === 'success' ? '#25d366' : type === 'error' ? '#ff5b6b' : '#5b8cff',
      color: '#fff',
      padding: '12px 22px',
      borderRadius: '10px',
      fontWeight: '700',
      zIndex: 9999,
      boxShadow: '0 10px 30px rgba(0,0,0,0.4)',
      animation: 'slideUp .3s ease',
    });
    document.body.appendChild(t);
    setTimeout(() => { t.style.opacity = '0'; t.style.transition = 'opacity .3s'; }, 2400);
    setTimeout(() => t.remove(), 2800);
  }

  refresh();
  return { open, close, refresh, updateUI, toast };
})();
window.Auth = Auth;
