"""
Web-based Telegram setup wizard
Allows user to authenticate via a browser form instead of terminal.

This is a separate FastAPI app on port 8001 that:
  1. Shows a form to enter phone + OTP code
  2. Sends the code via Pyrogram
  3. Saves the session file that main.py uses

Run with: python setup_web.py
Then visit: http://localhost:8001
"""
import os
import asyncio
from pathlib import Path
from fastapi import FastAPI, Form, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from pyrogram import Client
from dotenv import load_dotenv

load_dotenv()

API_ID = int(os.getenv("API_ID", "36041141"))
API_HASH = os.getenv("API_HASH", "192dd9c6f9a766c7880bc74a59d53d2d")
PHONE = os.getenv("ADMIN_PHONE", "+201143645282")

BASE = Path(__file__).resolve().parent
SESSION = str(BASE / "anadata_session")

app = FastAPI(title="ANA DATA Setup")

SETUP_HTML = """
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <title>إعداد تليجرام - ANA DATA</title>
  <style>
    body {
      font-family: 'Tajawal', system-ui, sans-serif;
      background: linear-gradient(135deg, #0a0d1a 0%, #1a2147 100%);
      color: #e9ecf6; min-height: 100vh; margin: 0;
      display: grid; place-items: center; padding: 20px;
    }
    .card {
      background: rgba(28, 34, 64, 0.7);
      backdrop-filter: blur(20px);
      border: 1px solid rgba(255,255,255,0.1);
      border-radius: 22px; padding: 40px; max-width: 460px; width: 100%;
      box-shadow: 0 24px 60px rgba(0,0,0,0.4);
    }
    h1 { margin: 0 0 8px; font-size: 26px; }
    .sub { color: #9aa3c2; margin-bottom: 26px; font-size: 14px; }
    label { display: block; margin-bottom: 8px; font-size: 13px; color: #9aa3c2; font-weight: 700; }
    input {
      width: 100%; padding: 14px; border-radius: 10px;
      background: rgba(15,19,37,0.8); border: 1px solid rgba(255,255,255,0.1);
      color: #fff; font-size: 15px; font-family: inherit;
      margin-bottom: 18px; box-sizing: border-box;
    }
    input:focus { outline: none; border-color: #5b8cff; box-shadow: 0 0 0 3px rgba(91,140,255,0.2); }
    button {
      width: 100%; padding: 14px; border: none; border-radius: 10px;
      background: linear-gradient(135deg, #5b8cff, #7a5cff); color: #fff;
      font-size: 15px; font-weight: 700; cursor: pointer;
      font-family: inherit; transition: transform .15s;
    }
    button:hover { transform: translateY(-1px); }
    button:disabled { opacity: 0.6; cursor: not-allowed; }
    .msg { padding: 12px; border-radius: 10px; margin-bottom: 18px; font-size: 14px; }
    .ok { background: rgba(37,211,102,0.15); color: #25d366; border: 1px solid rgba(37,211,102,0.3); }
    .err { background: rgba(255,91,107,0.15); color: #ff5b6b; border: 1px solid rgba(255,91,107,0.3); }
    .info { background: rgba(91,140,255,0.15); color: #5b8cff; border: 1px solid rgba(91,140,255,0.3); }
    .step { display: none; }
    .step.active { display: block; }
    .logo { display: flex; align-items: center; gap: 12px; margin-bottom: 24px; }
    .logo-icon { width: 44px; height: 44px; background: linear-gradient(135deg, #5b8cff, #7a5cff); border-radius: 12px; display: grid; place-items: center; font-size: 22px; }
    code { background: rgba(0,0,0,0.4); padding: 2px 8px; border-radius: 4px; font-size: 13px; }
  </style>
</head>
<body>
  <div class="card">
    <div class="logo">
      <div class="logo-icon">⚡</div>
      <h1>إعداد تليجرام</h1>
    </div>
    <p class="sub">عشان الموقع يجيب أرقام حقيقية من تليجرام، هنعمل تسجيل دخول مرة واحدة بس.</p>

    <div id="msg"></div>

    <div class="step active" id="step1">
      <p style="color:#9aa3c2;font-size:14px;">الرقم المسجل في الـ Backend:</p>
      <code style="display:block;padding:14px;border-radius:10px;margin-bottom:18px;font-size:18px;text-align:center;">__PHONE__</code>
      <button onclick="sendCode()">📲 ابعتلي الكود على الرقم ده</button>
    </div>

    <div class="step" id="step2">
      <label>كود التحقق من تليجرام</label>
      <input type="text" id="codeInput" placeholder="12345" maxlength="6" inputmode="numeric" autocomplete="off">
      <button onclick="verifyCode()">✅ تأكيد الكود</button>
      <p style="text-align:center;margin-top:14px;font-size:13px;color:#9aa3c2;">
        الكود وصلك على تطبيق تليجرام (Telegram app notification)
      </p>
    </div>

    <div class="step" id="step3">
      <div class="msg ok">✅ تم تسجيل الدخول بنجاح!</div>
      <p>دلوقتي تقدر تقفل الصفحة دي وتستخدم الموقع.</p>
      <button onclick="window.close()">حسناً</button>
    </div>
  </div>

  <script>
    function showMsg(text, type) {
      const m = document.getElementById('msg');
      m.innerHTML = '<div class="msg ' + type + '">' + text + '</div>';
    }
    function clearMsg() { document.getElementById('msg').innerHTML = ''; }

    async function sendCode() {
      clearMsg();
      const btn = event.target;
      btn.disabled = true; btn.textContent = 'جاري الإرسال...';
      try {
        const res = await fetch('/send-code', { method: 'POST' });
        const data = await res.json();
        if (data.ok) {
          document.getElementById('step1').classList.remove('active');
          document.getElementById('step2').classList.add('active');
          showMsg('تم إرسال الكود على تليجرام — افتح التطبيق هتلاقيه', 'info');
        } else {
          showMsg('حصل خطأ: ' + data.error, 'err');
          btn.disabled = false; btn.textContent = '📲 ابعتلي الكود على الرقم ده';
        }
      } catch (e) {
        showMsg('حصل خطأ في الاتصال', 'err');
        btn.disabled = false; btn.textContent = '📲 ابعتلي الكود على الرقم ده';
      }
    }

    async function verifyCode() {
      clearMsg();
      const code = document.getElementById('codeInput').value.trim();
      if (!code) { showMsg('اكتب الكود الأول', 'err'); return; }
      const btn = event.target;
      btn.disabled = true; btn.textContent = 'جاري التحقق...';
      try {
        const res = await fetch('/verify', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ code })
        });
        const data = await res.json();
        if (data.ok) {
          document.getElementById('step2').classList.remove('active');
          document.getElementById('step3').classList.add('active');
        } else {
          showMsg('كود غلط: ' + data.error, 'err');
          btn.disabled = false; btn.textContent = '✅ تأكيد الكود';
        }
      } catch (e) {
        showMsg('حصل خطأ', 'err');
        btn.disabled = false; btn.textContent = '✅ تأكيد الكود';
      }
    }
  </script>
</body>
</html>
"""

state = {"client": None, "phone_code_hash": None, "phone": None}


@app.get("/", response_class=HTMLResponse)
async def index():
    return SETUP_HTML.replace("__PHONE__", PHONE)


@app.post("/send-code")
async def send_code():
    global state
    try:
        if state["client"]:
            try:
                await state["client"].disconnect()
            except Exception:
                pass

        state["client"] = Client(SESSION, api_id=API_ID, api_hash=API_HASH)
        await state["client"].connect()
        sent = await state["client"].send_code(PHONE)
        state["phone_code_hash"] = sent.phone_code_hash
        state["phone"] = PHONE
        return {"ok": True}
    except Exception as e:
        return {"ok": False, "error": str(e)[:200]}


@app.post("/verify")
async def verify(payload: dict):
    code = (payload.get("code") or "").strip()
    if not code or not state.get("client") or not state.get("phone_code_hash"):
        return {"ok": False, "error": "ابدأ بإرسال الكود الأول"}
    try:
        await state["client"].sign_in(
            phone_number=state["phone"],
            phone_code_hash=state["phone_code_hash"],
            phone_code=code,
        )
        me = await state["client"].get_me()
        await state["client"].disconnect()
        return {
            "ok": True,
            "user": {
                "name": me.first_name,
                "username": me.username,
                "id": me.id,
            }
        }
    except Exception as e:
        return {"ok": False, "error": str(e)[:200]}


@app.get("/status")
async def status():
    session_file = Path(SESSION + ".session")
    return {
        "session_exists": session_file.exists(),
        "phone": PHONE,
    }


if __name__ == "__main__":
    import uvicorn
    print("=" * 50)
    print("  ANA DATA - Telegram Setup Wizard")
    print("=" * 50)
    print(f"  Open: http://localhost:8001")
    print("=" * 50)
    uvicorn.run(app, host="0.0.0.0", port=8001)
